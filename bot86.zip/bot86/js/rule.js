var count_a=0,count_b=0,count_c=0,count_d=0,tick,epoch,spot=[],token='',time_out=0,total_stake=0,
    date_epoch=0,pattern='',p_up=0,p_down=0,signal='',op='',open_slave=0,start_tim,recover=0,abc=0,
    analis_pattern=1,reverse=0,follow=0,spot_entry=0,spot_exit=0,go_open=0,dis_display='',margin_percent=0,
    entry_time=0,entry_spot=0,start_time='',bulk_trading='',result='',barr='',akun_terdaftar=0;
var longcode,bid_price,buy_price,payout=0,is_expired=0,idforget,entry_tick,current_spot,tick_count,turn_over=0,
    exit_tick,exit_spot,win_percent=0,bid_percent=0,end_proposal=0,position='',profit=0,total=0,sell=0,analis_tick=0,
    trade_count=0,trade_win=0,trade_loss=0,count_marti=0,count_compound=0;
var stake = 0,stop_loss=0,stop_lost=0,take_profit=0,max_compound=0,enable_compound=0,count_martingle_strategy='',enable_martingle_strategy='',
    enable_max_martingle='',max_martingle=0,martingle=0,enable_martingle='',end_spot=0,type_duration='',duration=0,sell_price,
    metode='',count_slave=0,mode='',count_signal='',barrier=0,stake_first=0,type_trade='',slic=[],volatil=[],volidx=[],market=0;
var token_1,balance=0,loginid,bulk_trading='',p_up=0,p_down=0,multi_trade = 0,abx=-1;
 
function log_out(){
   var cookies = document.cookie.split(";");
   for (var i = 0; i < cookies.length; i++)
     deleteCookie(cookies[i].split("=")[0]);
   window.location.replace('login.html');
}
function deleteCookie(name){
    setCookie(name,"",-1);
}
function setCookie(cname,cvalue,exdays) {
    var d = new Date();
    d.setTime(d.getTime() + (exdays*24*60*60*1000));
    var expires = "expires=" + d.toGMTString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}
function cecking_token(){
var bulk_trading = document.getElementById("bulktrading").checked;
var url ='wss://ws.binaryws.com/websockets/v3?app_id=3339';
      ws= new ReconnectingWebSocket(url);
      ws.debug = true;
      ws.timeoutInterval = 5400;
      token = $('#token_api').val();
if(bulk_trading == true){
  if(user == 'arif' ||  user == 'adam' || user == 'yanas'){
   ws.onopen=function() {
   ws.send(JSON.stringify({authorize: token.split(',')[0]}));
   ws.send(JSON.stringify({ticks : volidx})); 
   
    }
   }else{
 token = $('#token_api').val();
   ws.onopen=function() {
ws.send(JSON.stringify({authorize: token}));
ws.send(JSON.stringify({ticks : volidx})); 

    }
  }}else{
   token = $('#token_api').val();
   ws.onopen=function() {
ws.send(JSON.stringify({authorize: token}));  
ws.send(JSON.stringify({ticks : volidx})); 

}}
    ws.onmessage = function(msg) {
    var data = JSON.parse(msg.data);
    if(data.authorize){
    balance = Number(data.authorize.balance);
    email = data.authorize.email;
    loginid = data.authorize.loginid;
   document.getElementById('dis_balance').innerHTML = balance;
   document.getElementById('dis_email').innerHTML = '<i class="fa fa-vk"></i> Email : '+email;
   document.getElementById('dis_account').innerHTML = '<i class="fa fa-user"></i> Account : '+loginid;
   //alert(data_email[0])
   for(var abx=0;abx<data_email.length;abx++){
   if(email == data_email[abx]){akun_terdaftar = 1;break;}
}
   if(akun_terdaftar != 1){
      if(user == 'arif' || user == 'adam' || user == 'yanas')
        {akun_terdaftar = 1}else{
              ws.close();alert('MAAF AKUN ANDA TIDAK TERDAFTAR !!');log_out();}
            }else{
              console.debug('TERDAFTAR');
              start_trade();
            }}
  if(data.tick){
              start_trade();
  }

            
          
}
}

function saving(){
var bulk_trading = document.getElementById("bulktrading").checked;
    if(bulk_trading == true){
      multi_trade = 1;}
    
    market = Number($('#market').val());
    volidx = ['','R_10','R_100','R_25','R_50','R_75','RDBEAR','RDBULL'][market];
    volatil = ['','V 10','V 100','V 25','V 50','V 75', 'V BEAR','V BULL'][market];
    slic = [0,-2,-1,-1,-1,-3,-1,-2][market];
  type_trade = $('#type_trade').val();
  stake_first = Number($('#stake').val());
  barrier = Number($('#barrier').val());
  count_signal = Number($('#count_signal').val());
  mode = $('#mode').val();
  count_slave = Number($('#count_slave').val());
  metode = $('#metode').val();
  duration = Number($('#duration').val());
  type_duration = $('#type_duration').val();
  if(type_duration == 't'){end_spot = duration + 1;time_out = end_spot * 2050;turn_over=0.10;
    }else if(type_duration == 's'){end_spot = duration / 2;time_out = (end_spot + 1) * 20800;turn_over=0.10;
     }else if(type_duration == 'm'){end_spot = duration * 30;time_out = end_spot * 2080;turn_over=0.75;if(user != 'adam' || user != 'arif' || user != 'yanas'){turn_over=0.50;}
    }else if(type_duration == 'h'){end_spot = duration * 1800;time_out = end_spot * 2080;turn_over=0.75;if(user != 'adam' || user != 'arif' || user != 'yanas'){turn_over=0.50;}
      }else{end_spot = duration * 43200 ;time_out = end_spot * 2080;turn_over=0.75;if(user != 'adam' || user != 'arif' || user != 'yanas'){turn_over=0.50;}}
  enable_martingle = document.getElementById("enable_martingle").checked;
  martingle = Number($('#martingle').val());
  enable_max_martingle = document.getElementById("enable_max_martingle").checked;
  max_martingle = Number($('#max_martingle').val());
  enable_martingle_strategy = document.getElementById("enable_martingle_strategy").checked;
  count_martingle_strategy = $('#count_martingle_strategy').val();
  enable_compound = document.getElementById("enable_compound").checked;
  max_compound = Number($('#max_compound').val());
  take_profit = Number($('#take_profit').val());
  stop_lost = Number($('#stop_loss').val());
  stop_loss = -stop_lost;
  stake = stake_first;

  /*
  alert('volid '+volidx+' volatil'+ volatil+' slic '+slic+' type trade '+type_trade+'\nstake firs '+stake_first+' barrier '+barrier+' count_signal '+count_signal+'')
    alert('mode '+mode+' count_slave '+count_slave+' metode '+metode+' type_duration '+type_duration+' enable_martingle '+enable_martingle+' martingle' +martingle)
    alert(' enable_martingle_strategy '+enable_martingle_strategy+' count_martingle_strategy'+count_martingle_strategy+' enable_compound'+enable_compound+' max_compound'+max_compound+' take_profit'+take_profit+' stop_lost'+stop_loss)
    */
    document.getElementById('dis_market').innerHTML = volatil;
    document.getElementById('dis_take_profit').innerHTML = take_profit;
    document.getElementById('dis_stop_loss').innerHTML = stop_lost;
}
function re_conecting(){
var bulk_trading = document.getElementById("bulktrading").checked;
var url ='wss://ws.binaryws.com/websockets/v3?app_id=3339';
      ws= new ReconnectingWebSocket(url);
      ws.debug = true;
      ws.timeoutInterval = 5400;
      token = $('#token_api').val();
      //saving();
if(multi_trade == 1 || bulk_trading == true){
  if(user == 'arif' || user == 'adam' || user == 'yanas'){
   ws.onopen=function() {
ws.send(JSON.stringify({authorize: token.split(',')[0]}));
    }
   }else{
 token = $('#token_api').val();
   ws.onopen=function() {
ws.send(JSON.stringify({authorize: token}));
    }
  }}else{
   token = $('#token_api').val();
   ws.onopen=function() {
ws.send(JSON.stringify({authorize: token}));  
}}
    ws.onmessage = function(msg) {
    var data = JSON.parse(msg.data);
    //if(data.authorize.email != data_email[abx]){alert('AKUN TIDAK TERDAFTAR');log_out();}
    start_trade();
}}
function start_trading(){
  //re_conecting();
  analis_pattern = 1;
  start_trade();
}
function start_trade(){
  //re_conecting();
    
    signal = 'Wait';
  document.getElementById('dis_signal').innerHTML = signal;
      ws.send(JSON.stringify({ticks : volidx})); 
    ws.onmessage = function(msg) {
    var data = JSON.parse(msg.data);
        count_a++;count_b++;
        if(data.tick){
            tick = data.tick.quote;
            epoch = new Date(data.tick.epoch*1000).toString().slice(16,24);
            time = epoch.slice(6,8);
            spot[count_a] = Number(data.tick.quote);
            date_epoch=Number(data.tick.epoch);
        }
        if(user != 'adam' || user != 'arif' || user != 'yanas'){
        if(date_epoch >= data_expired[abx]){ws.close();alert('EXPIRED');log_out();
        }}
            if(count_a == 2){start_tim = epoch}
        analis_tick = 1;
       document.getElementById('dis_spot').innerHTML = tick.slice(0, slic);
       document.getElementById('dis_start_time').innerHTML = '<i class="fa fa-sign-in"></i>Start Time : '+start_tim;
       document.getElementById('dis_time').innerHTML = '<i class="fa fa-sign-out"></i>Now Time : '+epoch;
if(count_b > 5){
 if(analis_pattern == 1){
    count_c++;
   if(count_c == 1){spot_entry = Number(tick)}
   if(count_c >= (count_signal+1)){spot_exit = Number(tick);
      if(spot_exit > spot_entry){p_up++;p_down=0;}
      if(spot_exit < spot_entry){p_up=0;p_down++;}
       count_c=0;
     }
   dis_display = '[ Down '+p_down+' Up '+p_up+' ] [ '+count_c+' ]'; 
   document.getElementById('dis_indicator').innerHTML = '<i class="fa fa-sign-out"></i> '+dis_display;
   if(p_up >= count_slave){p_up = 0;
     if(mode == 'reverse'){
       signal = 'Fall';op = 'PUT';
    }else{
       signal = 'Rise';op = 'CALL';
    } 
    go_open = 1;analis_pattern = 0;   
    }
   if(p_down >= count_slave){p_down = 0;
       if(mode == 'follow'){
       signal = 'Fall';op = 'PUT';
    }else{
       signal = 'Rise';op = 'CALL';
    }
    go_open = 1;analis_pattern = 0;
    }
    }
 if(go_open == 1){
  if(hedging_active != 1){
 //ws.send(JSON.stringify({"forget_all": "ticks"}));
  go_open = 0;count_c = 0;count_b = 0;
  open_position();
 }else{
  click_play();
 }    
}

 if(total >= take_profit){ws.close();alert('TAKE PROFIT YEAH !!');}
 if(total <= stop_loss){ws.close();alert('STOP LOSS !!');}
}}
function take_contract_id(){
analis_pattern=3;
  if(multi_trade == 1){
        ws.onmessage = function(msg){
        var data = JSON.parse(msg.data);
      if(data.error){trade_count--;open_position();}
      if(data.buy_contract_for_multiple_accounts){
          balance_after = data.buy_contract_for_multiple_accounts.result[0].balance_after;
          longcode = data.buy_contract_for_multiple_accounts.result[0].longcode;
          shortcode = data.buy_contract_for_multiple_accounts.result[0].shortcode;
          start_time = data.buy_contract_for_multiple_accounts.result[0].start_time;
          contract_id = data.buy_contract_for_multiple_accounts.result[0].contract_id;
          buy_price = data.buy_contract_for_multiple_accounts.result[0].buy_price;
          purchase_time = data.buy_contract_for_multiple_accounts.result[0].purchase_time;
          transaction_id = data.buy_contract_for_multiple_accounts.result[0].transaction_id;
          payout = data.buy_contract_for_multiple_accounts.result[0].payout;
          purchase_timestamp = new Date(purchase_time*1000-25200000).toString().slice(16,24);
 setTimeout(function(){request_proposal(contract_id);}, time_out);
      }    }  
  }else{
        ws.onmessage = function(msg){
        var data = JSON.parse(msg.data);
        if(data.error){message=data.error.message;alert('error: '+message);}
        if(data.buy){
          balance_after = data.buy.balance_after;
          longcode = data.buy.longcode;
          shortcode = data.buy.shortcode;
          start_time = data.buy.start_time;
          contract_id = data.buy.contract_id;
          buy_price = data.buy.buy_price;
          purchase_time = data.buy.purchase_time;
          transaction_id = data.buy.transaction_id;
          payout = data.buy.payout;
          purchase_timestamp = new Date(purchase_time*1000-25200000).toString().slice(16,24);
 setTimeout(function(){request_proposal(contract_id);}, time_out);

        }
      }}
}
function open_position(){trade_count++;analis_tick = 2;
  if(recover == 1){
    recover = 0;
    
    op = recovery_op();
  }
  if(type_trade == 'higherlower' || type_trade == 'nottouch'){
    if(op == 'CALL'){barr = '-'+ barrier;playAudio('oprise');
  if(type_trade == 'nottouch'){ op = 'NOTOUCH';}
     }else{barr = '+'+ barrier;playAudio('opfall');if(type_trade == 'nottouch'){op = 'NOTOUCH'}}
  }else{
    if(op == 'CALL'){barr = '+'+ barrier;playAudio('oprise');if(type_trade == 'touch'){op = 'ONETOUCH'}
    }else{barr = '-'+ barrier;playAudio('opfall');if(type_trade == 'touch'){op = 'ONETOUCH'}}
  }
  total_stake += stake;
document.getElementById('dis_total_stake').innerHTML = '<i class="fa fa-money"></i>Total Stake : '+total_stake.toFixed(2);
document.getElementById('dis_total_turnover').innerHTML = '<i class="fa fa-bitcoin"></i>Turn Over : '+(total_stake*(turn_over/100)).toFixed(4);
document.getElementById('dis_signal').innerHTML = signal;
if(multi_trade == 1){
  //alert('bulktrading aktif, token '+token);
            ws.send(JSON.stringify({
              parameters: {
                amount: stake,
                basis: 'stake',
                contract_type: op,
                currency: 'USD',
                barrier: barr,
                duration: duration,
                duration_unit: type_duration,
                symbol: volidx
              },
              buy_contract_for_multiple_accounts: '1',
              price: stake,
              tokens: token.split(',')
          }));
take_contract_id();

}else{
            ws.send(JSON.stringify({
              parameters: {
                amount: stake,
                basis: 'stake',
                contract_type: op,
                currency: 'USD',
                barrier: barr,
                duration: duration,
                duration_unit: type_duration,
                symbol: volidx
              },
              price: stake,
              buy: '1'
          }));
  take_contract_id();

}
}
function request_proposal(contract_id) {
      ws.send(JSON.stringify({
          proposal_open_contract: 1,
          subscribe: 1,
          contract_id: contract_id
      }));
      analis_tick = 3;
      ws.onmessage = function(msg) {
          var data = JSON.parse(msg.data);
          if(data.error){request_proposal(contract_id)}
          if(data.proposal_open_contract){
              longcode = data.proposal_open_contract.longcode;
              bid_price = Number(data.proposal_open_contract.bid_price);
              buy_price = Number(data.proposal_open_contract.buy_price);
              payout = data.proposal_open_contract.payout;
              is_expired = data.proposal_open_contract.is_expired;
              idforget = data.proposal_open_contract.id;
              entry_tick = data.proposal_open_contract.entry_tick;
              current_spot = data.proposal_open_contract.current_spot;
              tick_count= data.proposal_open_contract.tick_count;
              exit_tick= data.proposal_open_contract.exit_tick;
              date_start = data.proposal_open_contract.date_start;
              current_spot_time = Number(data.proposal_open_contract.current_spot_time);
              date_expiry = Number(data.proposal_open_contract.date_expiry);
              purchase_timestamp = new Date(date_start*1000-25200000).toString().slice(16,24);
 document.getElementById('dis_time').innerHTML = '<i class="fa fa-sign-out"></i>Now Time : '+new Date(data.proposal_open_contract.current_spot_time*1000).toString().slice(16,24);
document.getElementById('dis_spot').innerHTML = current_spot;
if(current_spot_time >= date_expiry && bid_price >= 0){
  is_expired = 0;
      if(bid_price == payout) {
        end_proposal = 1;
        position = 'Won';
        profit = (bid_price - buy_price);
        total += profit;
        sell = bid_price;
        playAudio('win');
        //if(reverse >= count_slave){reverse++;follow=0;result+='W';}else{reverse=0;follow++;result+='W';}
        trade_win++;count_marti = 0;
        margin_percent = (total / balance) * 100;
       $('tbody').append('<tr style="color: green"><td>'+trade_count+'</td><td>'+signal+'</td><td>'+position+'</td><td>'+transaction_id+'</td><td>'+purchase_timestamp+'</td><td>'+payout+'</td><td>'+sell+'</td><td>'+stake.toFixed(2)+'</td><td>'+profit.toFixed(2)+'</td></tr>');                          
     

        if(enable_compound == true){
          count_compound++;stake += profit;
          if(count_compound > max_compound){
            stake = stake_first;
            count_compound = 0;
          }
        }else{
          if(enable_martingle == true || enable_martingle_strategy == true){
          stake = stake_first;count_d = 0;
        }
        }
      document.getElementById('dis_won').innerHTML = trade_win;
      document.getElementById('dis_total').innerHTML = total.toFixed(2);
      document.getElementById('dis_balance_after').innerHTML = (total + balance).toFixed(2);
      } 


      if (bid_price == 0){
        end_proposal = 1;
        position = 'Loss';
        profit = - stake;
        total += profit;
        sell = 0.00;
        playAudio('loss');
        trade_loss++;count_compound = 0;
        margin_percent = (total / balance) * 100;
       document.getElementById('dis_loss').innerHTML = trade_loss;
       document.getElementById('dis_total').innerHTML = total.toFixed(2);
       document.getElementById('dis_balance_after').innerHTML = (total + balance).toFixed(2);
       $('tbody').append('<tr style="color: red"><td>'+trade_count+'</td><td>'+signal+'</td><td>'+position+'</td><td>'+transaction_id+'</td><td>'+purchase_timestamp+'</td><td>'+payout+'</td><td>0.00</td><td>'+stake.toFixed(2)+'</td><td>'+profit.toFixed(2)+'</td></tr>'); 
    
        if(enable_martingle == true){
          stake *= martingle;
          count_compound = max_compound;
        }
        if(enable_max_martingle == true){
          count_marti++;
          count_compound = max_compound;
          if(count_marti > max_martingle){
            stake = stake_first;
            count_marti = 0;
          }
        }
        if(enable_martingle_strategy == true){
          count_d++;
          count_compound = max_compound;
          martingle_strategy = count_martingle_strategy.split('-')[count_d];
          stake = martingle_strategy[count_d];
          if(count_d > count_martingle_strategy.length - 1){
            count_d = 0;
            stake = stake_first;
          }
        }
    }}

if(end_proposal == 1){
  analis_pattern = 1;
   
  document.getElementById('dis_trade_a').innerHTML = '<i class="fa fa-trophy"></i> Trade : '+trade_count+' / Win : '+trade_win+' / Loss : '+trade_loss;
  document.getElementById('dis_margin').innerHTML = ''+margin_percent.toFixed(2) +' %';
  document.getElementById('dis_trade').innerHTML = trade_count;
  document.getElementById('dis_total').innerHTML = total.toFixed(2);
  document.getElementById('dis_total_a').innerHTML = '<i class="fa fa-dollar"></i>Total Profit : '+total.toFixed(2);
  end_proposal = 0;
    ws.send(JSON.stringify({"forget_all": "proposal_open_contract"}));
    ws.send(JSON.stringify({"forget_all": "ticks"}));
  if(metode == 'reanalise' || position == 'Won'){
  setTimeout(function(){start_trading()}, 3000);
  }else{

    recover = 1;
    setTimeout(function(){open_position();}, 1000);
  }

}
}}}
function recovery_signal(){
  if(metode == 'continue follow'){
      if(signal == 'Fall'){signal = 'Fall'}else{ signal = 'Rise'}
  }
   if(metode == 'continue reverse'){
      if(signal == 'Fall'){signal = 'Rise'}else{ signal = 'Fall'}
   }
   return signal;
}
function recovery_op(){
   if(metode == 'continue follow'){
     if( op == 'CALL'){op = 'CALL'}else if( op == 'CALL'){op = 'PUT'}else if( op == 'ONETOUCH'){ op = 'ONETOUCH'}else if(op == 'NOTOUCH'){op = 'NOTOUCH'}
   }
   if(metode == 'continue reverse'){
    if( op = 'CALL'){op = 'PUT'}else if( op == 'CALL'){op = 'CALL'}else if( op == 'ONETOUCH'){ op = 'ONETOUCH'}else if(op == 'NOTOUCH'){op = 'NOTOUCH'}
   }
  return op;
}
  function writelog(message){
          var pre = document.createElement("p");
          pre.style.wordWrap = "break-word";
          pre.innerHTML = message;
          output.appendChild(pre);
  }
  function playAudio(condition){
      var aud = new Audio();
        if(condition == 'win'){
          aud.src = 'sound/win.wav';
        } else if(condition == 'loss'){
          aud.src = 'sound/loss.wav';
        } else if(condition == 'opfall'){
          aud.src = 'sound/opfall.wav';
        } else if(condition == 'oprise'){
          aud.src = 'sound/oprise.wav';
        }
        aud.play();
}