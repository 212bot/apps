function go_to_signup(){
   var cookies = document.cookie.split(";");
   for (var i = 0; i < cookies.length; i++)
     deleteCookie(cookies[i].split("=")[0]);
     alert('SILAKAN HUBUNGI SAYA +62 822-215-444-60');
     window.location.replace('http://record.binary.com/_KAvxXllEJI8gX0HJlj6ztqBKp6lagYcO/1//?creative_id=%CREATIVE_ID%%');
}
function deleteCookie(name){
    setCookie(name,"",-1);
}
function account_ceck(){
var Username = $('#user_name').val();
    password = $('#pass_word').val();
var registered_a = 0,registered_b = 0;
    for(var a=0;a<user_name.length;a++){
    if(Username == user_name[a]){
        registered_a = 1;
if(password == pass_word[a]){
    registered_b = 1;
}
    if(registered_a == 1 && registered_b == 1){
    user = user_name[a];
    setCookie('username', user, 5);
    window.location.replace('index.html');
}break;}    }
    }
function setCookie(cname,cvalue,exdays) {
    var d = new Date();
    d.setTime(d.getTime() + (exdays*24*60*60*1000));
    var expires = "expires=" + d.toGMTString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}

function getCookie(cname) {
    var name = cname + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for(var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}