var count_a=0,count_b=0,count_c=0,count_d=0,tick,epoch,spot=[],token='',token_a='',time_out=0,total_stake=0,count_error=0,
    date_epoch=0,pattern='',p_up=0,p_down=0,signal='',op='',open_slave=0,start_tim,recover=0,token_a='',token_a='',token_b='',
    analis_pattern=1,reverse=0,follow=0,spot_entry=0,spot_exit=0,go_open=0,dis_display='',margin_percent=0,contract_a=0,contract_b=0,transaction_a=0,transaction_b=0,transaction_id_b=[],
    entry_time=0,entry_spot=0,start_time='',bulk_trading='',result='',barr='',akun_terdaftar=0;
var longcode,bid_price,buy_price,payout=0,is_expired=0,idforget,entry_tick,current_spot,tick_count,turn_over=0,step=0,
    exit_tick,exit_spot,win_percent=0,bid_percent=0,end_proposal=0,position='',profit=0,total=0,sell=0,analis_tick=0,
    trade_count=0,trade_win=0,trade_loss=0,count_marti=0,count_compound=0;
var stake = 0,stop_loss=0,stop_lost=0,take_profit=0,max_compound=0,enable_compound=0,count_martingle_strategy='',enable_martingle_strategy='',
    enable_max_martingle='',max_martingle=0,martingle=0,enable_martingle='',end_spot=0,type_duration='',duration=0,sell_price,
    metode='',count_slave=0,mode='',count_signal='',barrier=0,stake_first=0,type_trade='',slic=[],volatil=[],volidx=[],market=0;
var token_1,balance=0,loginid,bulk_trading='',p_up=0,p_down=0,multi_trade = 0,abx=-1;
var market_a='',market_b='',volidx_a=[],volidx_b=[],slic_b=[],type_trade_a='',type_trade_b='',stake_first_a='',stake_first_b='',
    barrier_a='',barrier_b='',duration_a=0,duration_b=0,type_duration_a='',type_duration_b='',volatil_a=[],volatil_b=[];
var balance_after_a,balance_after_b,longcode_b,longcode_a,shortcode_a,shortcode_b, start_time_a,start_time_b,contract_id_a=[],contract_id_b=[],
    buy_price_a,buy_price_b,purchase_time_a,purchase_time_b,transaction_id_a,transaction_id_b,payout_a,payout_b,purchase_time_a,purchase_timestamp_b;

function log_out(){
   var cookies = document.cookie.split(";");
   for (var i = 0; i < cookies.length; i++)
     deleteCookie(cookies[i].split("=")[0]);
   window.location.replace('login.html');
}
function deleteCookie(name){
    setCookie(name,"",-1);
}
function setCookie(cname,cvalue,exdays) {
    var d = new Date();
    d.setTime(d.getTime() + (exdays*24*60*60*1000));
    var expires = "expires=" + d.toGMTString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}

function manual_login(){
  market_c = Number($('#market_c').val());
  volidx_c = ['','R_10','R_100','R_25','R_50','R_75','RDBEAR','RDBULL'][market_c];
  volatil_c = ['','V 10','V 100','V 25','V 50','V 75', 'V BEAR','V BULL'][market_c];
  var url ='wss://ws.binaryws.com/websockets/v3?app_id=3260';
        ws= new ReconnectingWebSocket(url);
        ws.debug = true;
        ws.timeoutInterval = 5400;
        token_c = $('#token_api_c').val();
  if(user == 'arif' || user == 'yanas' || user == 'adam'){
     ws.onopen=function() {
     ws.send(JSON.stringify({authorize: token_c.split(',')[0]}));
     ws.send(JSON.stringify({ticks : volidx_c}));
   }}else{
     ws.onopen=function() {
     ws.send(JSON.stringify({authorize: token_c}));
     ws.send(JSON.stringify({ticks : volidx_c}));
      }
   }
        ws.onmessage = function(msg) {
      var data = JSON.parse(msg.data);
          if(data.authorize){
      balance = Number(data.authorize.balance);
      email = data.authorize.email;
      loginid = data.authorize.loginid;
      document.getElementById('dis_balance').innerHTML = balance;
      document.getElementById('dis_email').innerHTML = '<i class="fa fa-vk"></i> Email : '+email;
      document.getElementById('dis_account').innerHTML = '<i class="fa fa-user"></i> Account : '+loginid;
     for(var abx=0;abx<data_email.length;abx++){
     if(email == data_email[abx]){akun_terdaftar = 1;break;}
  }
     if(akun_terdaftar != 1){
        if(user == 'arif' || user == 'adam' || user == 'yanas')
          {akun_terdaftar = 1}else{
                ws.close();alert('MAAF AKUN ANDA TIDAK TERDAFTAR !!');log_out();}
              }
    }
          count_a++;
          if(data.tick){
              tick = data.tick.quote;
              epoch = new Date(data.tick.epoch*1000).toString().slice(16,24);
              time = epoch.slice(6,8);
              spot[count_a] = Number(data.tick.quote);
              date_epoch=Number(data.tick.epoch);
              }
              if(count_a == 2){start_tim = epoch}
         //document.getElementById('dis_spot_a').innerHTML = '<strong>'+tick.slice(0, slic)+'</strong>';

         document.getElementById('dis_spot').innerHTML = tick.slice(0, slic);
         document.getElementById('dis_start_time').innerHTML = '<i class="fa fa-sign-in"></i>Start Time : '+start_tim;
         document.getElementById('dis_time').innerHTML = '<i class="fa fa-sign-out"></i>Now Time : '+epoch;
  }
}


function go_purchase(){
  
  market_c = Number($('#market_c').val());
  volidx_c = ['','R_10','R_100','R_25','R_50','R_75','RDBEAR','RDBULL'][market_c];
  volatil_c = ['','V 10','V 100','V 25','V 50','V 75', 'V BEAR','V BULL'][market_c];
  slic = [0,-2,-1,-1,-1,-3,-1,-2][market_a];
  type_trade_c = $('#type_trade_c').val();
  stake_first_c = Number($('#stake_c').val());
  barrier_c = $('#barrier_c').val();
  duration_c = Number($('#duration_c').val());
  type_duration_c = $('#type_duration_c').val();
  if(type_duration_c == 't'){end_spot_c = duration_c + 1;time_out = end_spot_c * 2100;turn_over=0.10;
  }else if(type_duration_c == 's'){end_spot_c = duration_c / 2;time_out = (end_spot_c + 1) * 2300;turn_over=0.10;
  }else if(type_duration_c == 'm'){end_spot_c = duration_c * 30;time_out = end_spot_c * 2100;turn_over=0.75;
  }else if(type_duration_c == 'h'){end_spot_c = duration_c * 1800;time_out = end_spot_c * 2300;turn_over=0.75;
  }else{end_spot_a = duration_a * 43200 ;time_out = end_spot_a * 2300;turn_over=0.5;}

  total_stake += stake_first_c;
     trade_count ++;audioPlayer('ophedging');
     
    document.getElementById('dis_total_stake').innerHTML = '<i class="fa fa-money"></i>Total Stake : '+total_stake.toFixed(2);
    document.getElementById('dis_total_turnover').innerHTML = '<i class="fa fa-bitcoin"></i>Turn Over : '+(total_stake*(0.75/100)).toFixed(4);
    document.getElementById('dis_trade_a').innerHTML = '<i class="fa fa-trophy"></i> Trade : '+trade_count+' / Win : '+trade_win+' / Loss : '+trade_loss;
    document.getElementById('dis_signal').innerHTML = type_trade_c;
    if(user == 'adam' || user == 'arif' || user == 'yanas'){
            ws.send(JSON.stringify({
              parameters: {
                amount: stake_first_c,
                basis: 'stake',
                contract_type: type_trade_c,
                currency: 'USD',
                barrier: barrier_c,
                duration: duration_c,
                duration_unit: type_duration_c,
                symbol: volidx_c
              },
              buy_contract_for_multiple_accounts: '1',
              price: stake_first_c,
              tokens: token_c.split(',')
          }));
          ws.onmessage = function(msg){
          var data = JSON.parse(msg.data);
          if(data.error){message=data.error.message;alert('error: '+message);trade_count--;count_error++;}
          if(data.buy_contract_for_multiple_accounts){
          balance_after = data.buy_contract_for_multiple_accounts.result[0].balance_after;
          longcode = data.buy_contract_for_multiple_accounts.result[0].longcode;
          shortcode = data.buy_contract_for_multiple_accounts.result[0].shortcode;
          start_time = data.buy_contract_for_multiple_accounts.result[0].start_time;
          contract_id = data.buy_contract_for_multiple_accounts.result[0].contract_id;
          buy_price = data.buy_contract_for_multiple_accounts.result[0].buy_price;
          purchase_time = data.buy_contract_for_multiple_accounts.result[0].purchase_time;
          transaction_id = data.buy_contract_for_multiple_accounts.result[0].transaction_id;
          payout = data.buy_contract_for_multiple_accounts.result[0].payout;
          purchase_timestamp = new Date(purchase_time*1000).toString().slice(16,24);
          setTimeout(function(){request_proposal_c();}, time_out);

        }}
 }else{
          ws.send(JSON.stringify({
              parameters: {
                amount: stake_first_c,
                basis: 'stake',
                contract_type: type_trade_c,
                currency: 'USD',
                barrier: barrier_c,
                duration: duration_c,
                duration_unit: type_duration_c,
                symbol: volidx_c
              },
          price: stake_first_c,
          buy: '1'
 }));


          ws.onmessage = function(msg){
          var data = JSON.parse(msg.data);
          if(data.error){message=data.error.message;alert('error: '+message);trade_count--;count_error++;}
          if(data.buy){
            balance_after = data.buy.balance_after;
            longcode = data.buy.longcode;
            shortcode = data.buy.shortcode;
            start_time = data.buy.start_time;
            contract_id = data.buy.contract_id;
            buy_price = data.buy.buy_price;
            purchase_time = data.buy.purchase_time;
            transaction_id = data.buy.transaction_id;
            payout = data.buy.payout;
            purchase_timestamp = new Date(purchase_time*1000).toString().slice(16,24);

             setTimeout(function(){request_proposal_c();}, time_out);
}
          }
        }
      }
function loop_ing(){
  setTimeout(function(){go_purchase();}, time_out);
}
function request_proposal_c() {
           ws.send(JSON.stringify({
          proposal_open_contract: 1,
          //subscribe: 1,
          contract_id: contract_id
      }));

      ws.onmessage = function(msg) {
          var data = JSON.parse(msg.data);
          if(data.error){message=data.error.message;trade_count--;count_error++;}
          if(data.proposal_open_contract){
            // alert(contract_id_b[1]);
                  console.debug(contract_id);
                  console.debug('contract pertama');
              longcode = data.proposal_open_contract.longcode;
              bid_price = data.proposal_open_contract.bid_price;
              buy_price = data.proposal_open_contract.buy_price;
              payout = data.proposal_open_contract.payout;
              is_expired = data.proposal_open_contract.is_expired;
              idforget = data.proposal_open_contract.id;
              entry_tick = data.proposal_open_contract.entry_tick;
              current_spot = data.proposal_open_contract.current_spot;
              current_spot_time = Number(data.proposal_open_contract.current_spot_time);
              date_expiry = Number(data.proposal_open_contract.date_expiry);
              tick_count= data.proposal_open_contract.tick_count;
              exit_tick= data.proposal_open_contract.exit_tick;
              date_start = data.proposal_open_contract.date_start;
              purchase_timestamp = new Date(date_start*1000-25200000).toString().slice(16,24);
 if(if(current_spot_time >= date_expiry && bid_price >= 0){){
  is_expired = 0;
      if(bid_price == payout) {
        end_proposal = 1;
        position = 'Won';
        if(payout == undefined){payout = stake_first_c}
        profit = (payout - stake_first_c);
        total += profit;
        sell = payout;
        audioPlayer('winer');
        trade_win++;
        margin_percent = (total / balance) * 100;
      $('tbody').append('<tr style="color: green"><td>'+trade_count+'</td><td>'+data.proposal_open_contract.contract_type+'</td><td>Won</td><td>'+transaction_id+'</td><td>'+purchase_timestamp+'</td><td>'+payout+'</td><td>'+sell+'</td><td>'+stake_first_c.toFixed(2)+'</td><td>'+profit.toFixed(2)+'</td></tr>');
      document.getElementById('dis_won').innerHTML = trade_win;
      document.getElementById('dis_total').innerHTML = total.toFixed(2);
      document.getElementById('dis_balance_after').innerHTML = (total + balance).toFixed(2);
      }
      if (bid_price == 0){
        end_proposal = 1;
        position = 'Loss';
        if(payout == undefined){payout = stake_first_c}
        profit = - stake_first_c;
        total += profit;
        sell = 0.00;
        audioPlayer('losser');
        trade_loss++;
        margin_percent = (total / balance) * 100;
       document.getElementById('dis_loss').innerHTML = trade_loss;
       document.getElementById('dis_total').innerHTML = total.toFixed(2);
       document.getElementById('dis_balance_after').innerHTML = (total + balance).toFixed(2);
       $('tbody').append('<tr style="color: red"><td>'+trade_count+'</td><td>'+data.proposal_open_contract.contract_type+'</td><td>Loss</td><td>'+transaction_id+'</td><td>'+purchase_timestamp+'</td><td>'+payout+'</td><td>0.00</td><td>'+stake_first_c.toFixed(2)+'</td><td>-'+stake_first_c.toFixed(2)+'</td></tr>');
    }}

if(end_proposal == 1){
  document.getElementById('dis_trade_a').innerHTML = '<i class="fa fa-trophy"></i> Trade : '+trade_count+' / Win : '+trade_win+' / Loss : '+trade_loss;

  document.getElementById('dis_margin').innerHTML = ''+margin_percent.toFixed(2) +' %';
  document.getElementById('dis_trade').innerHTML = trade_count;
  document.getElementById('dis_total').innerHTML = total.toFixed(2);
  document.getElementById('dis_total_a').innerHTML = '<i class="fa fa-dollar"></i>Total Profit : '+total.toFixed(2);
  end_proposal = 0;
  ws.send(JSON.stringify({"forget_all":"proposal_open_contract"}));
  //go_purchase();
  goes_tick();
}
}}

}
function goes_tick(){
   ws.send(JSON.stringify({ticks : volidx_c}));
        ws.onmessage = function(msg) {
    var data = JSON.parse(msg.data);
        if(data.tick){count_a++;
            tick = data.tick.quote;
            epoch = new Date(data.tick.epoch*1000).toString().slice(16,24);
            time = epoch.slice(6,8);
            spot[count_a] = Number(data.tick.quote);
            date_epoch=Number(data.tick.epoch);
            if(count_a == 2){start_tim = epoch}
       document.getElementById('dis_spot').innerHTML = tick.slice(0, slic);
       document.getElementById('dis_signal').innerHTML = 'Wait';
       document.getElementById('dis_start_time').innerHTML = '<i class="fa fa-sign-in"></i>Start Time : '+start_tim;
       document.getElementById('dis_time').innerHTML = '<i class="fa fa-sign-out"></i>Now Time : '+epoch;
     }
}}
  function writelog(message){
          var pre = document.createElement("p");
          pre.style.wordWrap = "break-word";
          pre.innerHTML = message;
          output.appendChild(pre);
  }
  function audioPlayer(condition){
      var aud = new Audio();
        if(condition == 'winer'){
          aud.src = 'sound/winner.wav';
        } else if(condition == 'losser'){
          aud.src = 'sound/losser.wav';
        } else if(condition == 'ophedging'){
          aud.src = 'sound/ophedging.wav';
        }
        aud.play();
}
